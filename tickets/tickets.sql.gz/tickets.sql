-- MySQL dump 10.13  Distrib 5.1.37, for debian-linux-gnu (i486)
--
-- Host: localhost    Database: tickets
-- ------------------------------------------------------
-- Server version	5.1.37-1ubuntu5.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fonts`
--

DROP TABLE IF EXISTS `fonts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fonts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `size` varchar(255) NOT NULL,
  `wsize` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fonts`
--

LOCK TABLES `fonts` WRITE;
/*!40000 ALTER TABLE `fonts` DISABLE KEYS */;
INSERT INTO `fonts` VALUES (1,'arial','Arial','arial.ttf','12','60'),(2,'arialb','Arial Bold','arialbd.ttf','12','65'),(3,'ariali','Arial Italic','ariali.ttf','12','70'),(5,'georgia','Georgia','georgia.ttf','12','70');
/*!40000 ALTER TABLE `fonts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `thumb` varchar(255) NOT NULL,
  `count` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `uid` int(11) NOT NULL,
  `shared` tinyint(1) NOT NULL DEFAULT '1',
  `updated` datetime NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (37,'Blank Admission Ticket','files/Blank_admission_ticket.png','files/thumbs/Blank_admission_ticket.png',549,'2010-04-26 09:58:01',1,1,'2010-07-30 15:49:17',1),(33,'2010 Foodie Fest Complimentary VIP','files/Complimentary_VIP_Ticket.png','files/thumbs/Complimentary_VIP_Ticket.png',205,'2010-04-20 10:07:06',1,1,'2010-07-30 15:00:23',1),(32,'2010 Foodie Fest Paid Admission with dinner','files/Paid_Admission_Ticket_with_Dinner.png','files/thumbs/Paid_Admission_Ticket_with_Dinner.png',120,'2010-04-20 10:01:43',1,1,'2010-04-20 10:02:08',1),(31,'2010 Foodie Fest Paid Admission','files/Paid_Admission_Ticket.png','files/thumbs/Paid_Admission_Ticket.png',70,'2010-04-20 09:56:01',1,1,'2010-07-30 16:31:36',1),(30,'2010-06-09 Tri-tip dinner','files/Tri-tip.png','files/thumbs/Tri-tip.png',372,'2010-04-20 09:45:57',1,1,'2010-07-30 16:44:58',1),(29,'2010 VIP wristband','files/vip_ticket.png','files/thumbs/vip_ticket.png',100,'2010-04-14 13:58:04',1,1,'2010-04-20 10:25:32',1),(28,'2010 Sequoia Foodie Fest','files/foodiefest_ticket.png','files/thumbs/foodiefest_ticket.png',180,'2010-04-13 11:41:36',1,1,'2010-04-26 09:41:42',1),(83,'test1','files/test_ticket.png','files/thumbs/test_ticket.png',0,'0000-00-00 00:00:00',1,1,'0000-00-00 00:00:00',1);
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'bgcsequoias','def5dc846737d75e753296eb6c6722ef4ef501a3');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-08-09 14:31:05
